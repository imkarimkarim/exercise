def game(number):
    pass
